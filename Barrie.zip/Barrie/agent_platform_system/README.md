 Agent Platform System - User Roles & Database

 Project Goal
This project is a back-end design implementation of a user management system for an "Agent Platform," focusing on defining key user roles and demonstrating full CRUD (Create, Read, Update, Delete) operations on the database.

It fulfills the requirements of Assignment 2: User Roles & Database.

Key Features
User Roles: Admin, Player, Agent, and Club Manager are defined.
CRUD Operations: Full functionality for reading the user list, creating new users, and deleting existing users.
Technology Stack: PHP, SQL, and XAMPP (MySQL/MariaDB).
Security Focus: Passwords for new users are stored securely using PHP's `password_hash()` function.

---

 Setup and Installation

 1. Prerequisites
 XAMPP installed (with Apache and MySQL services running).
 A web browser.

2. File Placement
1.  Navigate to your XAMPP web root directory: `C:\xampp\htdocs\`.
2.  Create a new folder named `agent_platform_system`.
3.  Place the following three files inside this folder:
     `db_connect.php`
     `manage_users.php`
    `index.php`

3. Database Configuration

The database name used is `platform_agent`.

1.  Ensure Apache and MySQL are running in the XAMPP Control Panel.
2.  Open phpMyAdmin** in your browser (`http://localhost/phpmyadmin/`).
3.  Create a new database named `platform_agent`.
4.  Execute the following SQL commands in the SQL tab to set up the table and insert initial sample data for each role:

```sql
-- 1. Create the Users Table
CREATE TABLE users (
    id INT(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('Admin', 'Player', 'Agent', 'Club Manager') NOT NULL
);

-- 2. Insert Sample Data for each role
INSERT INTO users (username, password, email, role) VALUES
('platform_admin', 'adminpass', 'admin@platform.com', 'Admin'),
('star_player', 'playerpass', 'player1@platform.com', 'Player'),
('top_agent', 'agentpass', 'agent007@platform.com', 'Agent'),
('club_owner', 'clubpass', 'owner@club.com', 'Club Manager');