<?php
require_once 'db_connect.php';

// --- READ Operation ---
function getAllUsers($conn) {
    $sql = "SELECT id, username, email, role FROM users ORDER BY role, username";
    $result = $conn->query($sql);
    
    $users = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    return $users;
}

// --- CREATE Operation ---
function createUser($conn, $username, $password, $email, $role) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $conn->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $hashed_password, $email, $role);

    if ($stmt->execute()) {
        return "New user created successfully!";
    } else {
        if ($conn->errno == 1062) {
            return "Error: Username or Email already exists.";
        }
        return "Error creating user: " . $stmt->error;
    }
}

// --- DELETE Operation ---
function deleteUser($conn, $user_id) {
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        return "User ID $user_id deleted successfully!";
    } else {
        return "Error deleting user: " . $stmt->error;
    }
}

// --- Handler for Form Submissions ---

// Handle Add User
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password']; 
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    
    $message = createUser($conn, $username, $password, $email, $role);
    
    header("Location: index.php?message=" . urlencode($message));
    exit();
}

// Handle Delete User
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $user_id = (int)$_GET['id'];
    $message = deleteUser($conn, $user_id);
    header("Location: index.php?message=" . urlencode($message));
    exit();
}

// Fetch all users for display
$users = getAllUsers($conn);
?>